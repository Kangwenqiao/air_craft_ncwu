from ultralytics import YOLO
class predict:
    def __init__(self, **kwargs):
        model_path = "best.pt"
        self.own_model = YOLO(model_path)

    def detect_image(self, image_path):
        out = self.own_model.predict(image_path)
        boxes = out[0].boxes.data.cpu().numpy()
        boxes = boxes[:, [1, 0, 3, 2, 4, 5]]
        # boxes = boxes.detach().cpu().numpy()  # 注意：您可能不需要这行

        return boxes